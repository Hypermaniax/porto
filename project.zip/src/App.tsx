import { FormEvent, useEffect, useState } from "react"

type ButtonProps = {
  children: React.ReactNode
  href?: string
  variant?: "yellow" | "pink" | "blue" | "paper" | "black"
  download?: boolean
  className?: string
  onClick?: () => void
  type?: "button" | "submit"
}

function Button({
  children,
  href,
  variant = "yellow",
  download,
  className = "",
  onClick,
  type = "button",
}: ButtonProps) {
  const classes = `button button--${variant} ${className}`
  return href ? (
    <a className={classes} href={href} download={download} onClick={onClick}>
      {children}
    </a>
  ) : (
    <button className={classes} type={type} onClick={onClick}>
      {children}
    </button>
  )
}

function SectionTitle({
  index,
  children,
  inverse = false,
}: {
  index: string
  children: React.ReactNode
  inverse?: boolean
}) {
  return (
    <div className={`section-title ${inverse ? "section-title--inverse" : ""}`}>
      <span className="eyebrow">{index} / INDEX</span>
      <h2>{children}</h2>
    </div>
  )
}

const projects = [
  {
    number: "01",
    title: "Kinetic",
    subtitle: "A running app for people who hate running apps.",
    year: "2025",
    tags: ["PRODUCT", "MOBILE", "IDENTITY"],
    color: "yellow",
    visual: "kinetic",
  },
  {
    number: "02",
    title: "Noisy",
    subtitle: "Independent music discovery, turned all the way up.",
    year: "2024",
    tags: ["WEB", "CREATIVE DEV", "3D"],
    color: "blue",
    visual: "noisy",
  },
  {
    number: "03",
    title: "Common",
    subtitle: "Making local spaces easier to find and share.",
    year: "2024",
    tags: ["STRATEGY", "UX", "WEB APP"],
    color: "mint",
    visual: "common",
  },
  {
    number: "04",
    title: "Afterdark",
    subtitle: "An editorial platform for culture after hours.",
    year: "2023",
    tags: ["EDITORIAL", "WEB", "MOTION"],
    color: "pink",
    visual: "afterdark",
  },
]

const experience = [
  ["2023—NOW", "SENIOR PRODUCT DESIGNER", "STUDIO LOUD"],
  ["2021—2023", "UI/UX DESIGNER", "ODD PRACTICE"],
  ["2019—2021", "FRONTEND DEVELOPER", "SELF-EMPLOYED"],
]

function ProjectVisual({ type }: { type: string }) {
  return (
    <div
      className={`project-visual project-visual--${type}`}
      aria-hidden="true"
    >
      {type === "kinetic" && (
        <>
          <span className="visual-word">RUN</span>
          <span className="visual-pill">12.4 KM</span>
          <span className="visual-circle" />
        </>
      )}
      {type === "noisy" && (
        <>
          <span className="record" />
          <span className="visual-word">LOUDER!</span>
          <span className="sound-lines">|||||||||||</span>
        </>
      )}
      {type === "common" && (
        <>
          <span className="map-line map-line--one" />
          <span className="map-line map-line--two" />
          <span className="map-pin">+</span>
          <span className="visual-word">HERE</span>
        </>
      )}
      {type === "afterdark" && (
        <>
          <span className="moon">D</span>
          <span className="visual-word">02:17</span>
          <span className="stars">+ &nbsp; × &nbsp; + &nbsp; ×</span>
        </>
      )}
    </div>
  )
}

function App() {
  const [menuOpen, setMenuOpen] = useState(false)
  const [sent, setSent] = useState(false)

  useEffect(() => {
    document.body.style.overflow = menuOpen ? "hidden" : ""
    return () => {
      document.body.style.overflow = ""
    }
  }, [menuOpen])

  const closeMenu = () => setMenuOpen(false)
  const submitForm = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    setSent(true)
  }

  return (
    <div className="site-shell">
      <a className="skip-link" href="#main">
        SKIP TO CONTENT
      </a>

      <header className="navbar">
        <a className="logo" href="#top" aria-label="NAMA home">
          N<span>.</span>
        </a>
        <nav className="desktop-nav" aria-label="Primary navigation">
          <a href="#work">WORK</a>
          <a href="#about">ABOUT</a>
          <a href="#skills">SKILLS</a>
          <a href="#contact">CONTACT</a>
        </nav>
        <Button href="#contact" className="desktop-hire">
          HIRE ME ↗
        </Button>
        <button
          className="menu-toggle"
          type="button"
          aria-expanded={menuOpen}
          aria-controls="mobile-menu"
          aria-label={menuOpen ? "Close menu" : "Open menu"}
          onClick={() => setMenuOpen(!menuOpen)}
        >
          <span />
          <span />
        </button>
      </header>

      <div
        className={`mobile-menu ${menuOpen ? "mobile-menu--open" : ""}`}
        id="mobile-menu"
        aria-hidden={!menuOpen}
      >
        <div className="mobile-menu__number">MENU / 04</div>
        <nav aria-label="Mobile navigation">
          {["WORK", "ABOUT", "SKILLS", "CONTACT"].map((item, index) => (
            <a key={item} href={`#${item.toLowerCase()}`} onClick={closeMenu}>
              <span>0{index + 1}</span>
              {item}
            </a>
          ))}
        </nav>
        <a href="mailto:hello@nama.design">HELLO@NAMA.DESIGN ↗</a>
      </div>

      <main id="main">
        <section className="hero" id="top">
          <div className="hero__meta">
            <span>PRODUCT DESIGNER + FRONTEND DEVELOPER</span>
            <span>JAKARTA / GMT+7</span>
          </div>
          <div className="hero__headline-wrap">
            <h1>
              I BUILD
              <br />
              <span>LOUD</span> IDEAS
              <br />
              THAT WORK.
            </h1>
            <div className="sticker sticker--available">
              <span className="status-dot" />
              AVAILABLE
              <br />
              FOR WORK
            </div>
          </div>
          <div className="hero__bottom">
            <p>
              HEY, I’M <strong>[NAMA]</strong>. I TURN COMPLEX PROBLEMS INTO
              DIGITAL EXPERIENCES PEOPLE ACTUALLY WANT TO USE.
            </p>
            <div className="hero__actions">
              <Button href="#work">VIEW MY WORK ↓</Button>
              <Button
                href="data:text/plain;charset=utf-8,NAMA%20%E2%80%94%20Product%20Designer%20%2B%20Frontend%20Developer"
                variant="paper"
                download
              >
                DOWNLOAD CV ↗
              </Button>
            </div>
          </div>
        </section>

        <div className="marquee" aria-label="Design, build, repeat">
          <div className="marquee__track">
            DESIGN WITH INTENT ✦ BUILD WITH CODE ✦ BREAK THE BORING ✦ DESIGN
            WITH INTENT ✦ BUILD WITH CODE ✦ BREAK THE BORING ✦
          </div>
        </div>

        <section className="section work" id="work">
          <SectionTitle index="01">SELECTED WORK</SectionTitle>
          <div className="project-grid">
            {projects.map((project) => (
              <article
                className={`project-card project-card--${project.color}`}
                key={project.title}
              >
                <ProjectVisual type={project.visual} />
                <div className="project-card__meta">
                  <span>{project.number}</span>
                  <span>{project.year}</span>
                </div>
                <h3>{project.title}</h3>
                <p>{project.subtitle}</p>
                <div className="project-card__footer">
                  <div className="tags">
                    {project.tags.map((tag) => (
                      <span className="tag" key={tag}>
                        {tag}
                      </span>
                    ))}
                  </div>
                  <a
                    className="case-link"
                    href="#contact"
                    aria-label={`View ${project.title} case study`}
                  >
                    ↗
                  </a>
                </div>
              </article>
            ))}
          </div>
        </section>

        <section className="section about" id="about">
          <SectionTitle index="02">ABOUT ME</SectionTitle>
          <div className="about__grid">
            <div className="portrait-wrap">
              <img
                src="https://images.unsplash.com/photo-1553614186-5fc725ac6396?auto=format&fit=crop&w=1000&q=85"
                alt="Creative professional in a black and white editorial portrait"
              />
              <span className="photo-credit">
                PHOTO: PATRICK GILLESPIE / UNSPLASH
              </span>
              <div className="sticker sticker--curious">
                STAY
                <br />
                CURIOUS!
              </div>
            </div>
            <div className="about__copy">
              <p className="lead">
                I’M A DESIGNER WHO <mark>THINKS IN SYSTEMS</mark> AND A
                DEVELOPER WHO CARES ABOUT THE DETAILS.
              </p>
              <div className="body-copy">
                <p>
                  For the last 6 years, I’ve helped ambitious teams turn rough
                  ideas into useful, memorable products.
                </p>
                <p>
                  My sweet spot is right between design and code—where wild
                  ideas become real things that move, respond, and make sense.
                </p>
              </div>
              <Button href="#contact" variant="black">
                MORE ABOUT ME ↗
              </Button>
            </div>
          </div>
          <div className="stats">
            <div>
              <strong>06+</strong>
              <span>YEARS MAKING</span>
            </div>
            <div>
              <strong>42</strong>
              <span>PROJECTS SHIPPED</span>
            </div>
            <div>
              <strong>∞</strong>
              <span>COFFEE CONSUMED</span>
            </div>
          </div>
        </section>

        <section className="section skills" id="skills">
          <SectionTitle index="03">SKILLS &amp; TOOLS</SectionTitle>
          <div className="skills__layout">
            <div className="skill-cloud">
              {[
                "PRODUCT DESIGN",
                "UI/UX",
                "DESIGN SYSTEMS",
                "CREATIVE CODE",
                "PROTOTYPING",
                "INTERACTION",
                "ART DIRECTION",
                "ACCESSIBILITY",
              ].map((skill, index) => (
                <span
                  className={`skill-chip skill-chip--${(index % 4) + 1}`}
                  key={skill}
                >
                  {skill}
                </span>
              ))}
            </div>
            <div className="tool-grid" aria-label="Tools">
              {[
                "FIGMA",
                "REACT",
                "FRAMER",
                "WEBFLOW",
                "TYPESCRIPT",
                "RIVE",
              ].map((tool, index) => (
                <div className="tool" key={tool}>
                  <span>0{index + 1}</span>
                  <strong>{tool.slice(0, 2)}</strong>
                  <p>{tool}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="section experience">
          <SectionTitle index="04">EXPERIENCE</SectionTitle>
          <div className="timeline">
            {experience.map(([year, role, company], index) => (
              <div className="timeline__row" key={role}>
                <span>0{index + 1}</span>
                <time>{year}</time>
                <strong>{role}</strong>
                <span>{company}</span>
                <span aria-hidden="true">↗</span>
              </div>
            ))}
          </div>
        </section>

        <section className="contact" id="contact">
          <div className="contact__header">
            <span className="eyebrow">05 / DON’T BE SHY</span>
            <h2>
              LET’S WORK
              <br />
              TOGETHER<span>.</span>
            </h2>
            <div className="sticker sticker--mail">SEND IT! ↘</div>
          </div>
          <div className="contact__grid">
            <div className="contact__details">
              <p>
                GOT A PROJECT, A HALF-BAKED IDEA, OR JUST WANT TO SAY HELLO?
              </p>
              <a className="email-link" href="mailto:hello@nama.design">
                HELLO@NAMA.DESIGN ↗
              </a>
              <div className="socials">
                <a href="#top">LINKEDIN ↗</a>
                <a href="#top">DRIBBBLE ↗</a>
                <a href="#top">GITHUB ↗</a>
              </div>
            </div>
            <form onSubmit={submitForm}>
              <label>
                <span>YOUR NAME</span>
                <input name="name" required placeholder="TYPE IT HERE..." />
              </label>
              <label>
                <span>YOUR EMAIL</span>
                <input
                  name="email"
                  type="email"
                  required
                  placeholder="YOU@EMAIL.COM"
                />
              </label>
              <label>
                <span>YOUR MESSAGE</span>
                <textarea
                  name="message"
                  required
                  rows={4}
                  placeholder="TELL ME EVERYTHING..."
                />
              </label>
              <Button type="submit" variant="black">
                {sent ? "MESSAGE SENT — NICE!" : "SEND MESSAGE ↗"}
              </Button>
            </form>
          </div>
        </section>
      </main>

      <footer>
        <div>
          <a className="logo logo--footer" href="#top">
            N<span>.</span>
          </a>
          <p>DESIGNED LOUD. BUILT WITH CARE.</p>
        </div>
        <p>© 2025 [NAMA]. ALL RIGHTS RESERVED.</p>
        <a className="back-top" href="#top" aria-label="Back to top">
          ↑
        </a>
      </footer>
    </div>
  )
}

export default App
